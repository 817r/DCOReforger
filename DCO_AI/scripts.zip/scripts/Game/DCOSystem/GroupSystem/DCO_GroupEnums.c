enum GroupTactics
{
	ADVANCE,
	ASSAULT,
	DEFEND,
	BYPASS,
	WITHDRAW
}
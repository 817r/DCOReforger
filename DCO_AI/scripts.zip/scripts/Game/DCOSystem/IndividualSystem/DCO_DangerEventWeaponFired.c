[BaseContainerProps()]
modded class SCR_AIDangerReaction_WeaponFired
{
	protected SCR_AIUtilityComponent uti;
	vector dangerPos;
	override bool PerformReaction(notnull SCR_AIUtilityComponent utility, notnull SCR_AIThreatSystem threatSystem, AIDangerEvent dangerEvent, int dangerEventCount)
	{
		AIDangerEventWeaponFire eventWeaponFire = AIDangerEventWeaponFire.Cast(dangerEvent);		
		IEntity shooter = eventWeaponFire.GetObject();
		
		if (!shooter || !eventWeaponFire)
			return false;
		
		IEntity instigatorEntity = eventWeaponFire.GetInstigatorEntity();
		if (!instigatorEntity)
			return false;
		
		// Check faction relations, ignore if not enemy or there is no faction
		Faction instigatorFaction = SCR_AIFactionHandling.GetEntityPerceivedFaction(instigatorEntity);
		
		if (!instigatorFaction)
			return false;
		
		SCR_ChimeraAIAgent agent = SCR_ChimeraAIAgent.Cast(utility.GetOwner());
		
		uti = utility;
		bool myFactionIsMilitary = utility.IsMilitary();
		if (myFactionIsMilitary && !agent.IsEnemy(instigatorFaction))
			return false;
		
		// Get root entity of shooter, in case it is turret in vehicle hierarchy
		vector shotPos = eventWeaponFire.GetPosition();
		vector shotDir = eventWeaponFire.GetDirection();
		bool isShotSuppressed = eventWeaponFire.IsSuppressed();
		dangerPos = shotPos;
		vector myOrigin = utility.m_OwnerEntity.GetOrigin();
		float distance = vector.Distance(myOrigin, shotPos);
		float distanceSQ = vector.DistanceSq(myOrigin, shotPos);
		float dismountDist = utility.m_DCOConfig.GetDismountDistance();
		float dismountDistSq = dismountDist * dismountDist;
		bool isFlyby = IsFlyby(myOrigin, shotPos, shotDir, distance);
		bool endangeringForGroup = isFlyby || distance < ENDANGERING_FOR_GROUP_RADIUS;
		
		if (utility.m_AIInfo.HasUnitState(EUnitState.IN_VEHICLE) && distanceSQ > dismountDistSq)
		{
			return false;
		} else if (utility.m_AIInfo.HasUnitState(EUnitState.IN_VEHICLE) && distanceSQ <= dismountDistSq)
		{
			if (utility.m_AIInfo.HasUnitState(EUnitState.PILOT))
			{
				/*
				SCR_AIIdleBehavior_Driver driverBehavior = SCR_AIIdleBehavior_Driver.Cast(utility.FindActionOfType(SCR_AIIdleBehavior_Driver));
				if (driverBehavior)
					driverBehavior.SetPriority(SCR_AIActionBase.PRIORITY_ACTIVITY_COMBAT_WITH_VEHICLES);
				*/
			}
			else if (utility.m_AIInfo.HasUnitState(EUnitState.IN_TURRET))
			{
				/*float instDist = vector.Distance(eventWeaponFire.GetInstigatorEntity().GetOrigin(), utility.GetOrigin());
				float radius = Math.Map(instDist, 0, SCR_AICombatComponent.LONG_RANGE_COMBAT_DISTANCE, 2, 5);
				vector bbMax, bbMin;
				SCR_AISuppressionVolumeBase.CreateSuppressionBox(eventWeaponFire.GetInstigatorEntity().GetOrigin(), radius, 3, bbMin, bbMax);
				SCR_AISuppressionObjectVolumeBox createSupp = new SCR_AISuppressionObjectVolumeBox(bbMin, bbMax);
				SCR_AISuppressBehavior supp = new SCR_AISuppressBehavior(utility, null, createSupp, 5, 3);
				utility.AddAction(supp);*/	
			}
			else
			{
			 	CompartmentAccessComponent compartmentAccess = CompartmentAccessComponent.Cast(utility.m_OwnerEntity.FindComponent(CompartmentAccessComponent));
				if (!compartmentAccess)
					return false;
					 
				if (!compartmentAccess.IsInCompartment())
					return false;	
				
				SCR_AIGetOutVehicle getOutAction = new SCR_AIGetOutVehicle(utility, null, compartmentAccess.GetOwner(), priority: SCR_AIActionBase.PRIORITY_BEHAVIOR_GET_OUT_VEHICLE_HIGH_PRIORITY);
				utility.AddAction(getOutAction);		
				
				
				return super.PerformReaction(utility, threatSystem, dangerEvent, dangerEventCount);	
			}

		}
		
		// Is it a flyby?
		
		
		bool isAudible = IsAudiable(distance, isShotSuppressed);
		
		float timeTillFlyby_s = float.MAX;
		float timeTillGunshotHeard_s = float.MAX;
		

		if (isFlyby)
		{
			float projectileSpeed = eventWeaponFire.GetInitialSpeed();
			WorldTimestamp eventTimestamp = eventWeaponFire.GetTimestamp();
			float flightTime_s = distance / projectileSpeed;
			WorldTimestamp flybyTimestamp = eventTimestamp.PlusSeconds(flightTime_s + PROJECTILE_FLYBY_DELAY_S);
			timeTillFlyby_s = flybyTimestamp.DiffSeconds(GetGame().GetWorld().GetTimestamp());
			
			if (timeTillFlyby_s < 0)
				OnProjectileFlyby(utility, dangerEventCount, shotPos);
			else
			{
				utility.GetCallqueue().CallLater(OnProjectileFlyby, 1000*timeTillFlyby_s, false,
					utility, dangerEventCount, shotPos);
			}
		}
		
		if (isAudible)
		{
			WorldTimestamp eventTimestamp = eventWeaponFire.GetTimestamp();
			float wavefrontTravelTime_s = distance / SOUND_SPEED_MS;
			WorldTimestamp wavefrontArrivalTimestamp = eventTimestamp.PlusSeconds(wavefrontTravelTime_s);
			timeTillGunshotHeard_s = wavefrontArrivalTimestamp.DiffSeconds(GetGame().GetWorld().GetTimestamp());
			
			// Ignore the gunshot sound if projectile flies by sooner than sound of gunshot.
			// This is general case for majority of weapons. We don't want to notify the threat system twice.
			// Threat system was not tuned to be notified twice in such cases.
			bool ignoreGunshotHeard = isFlyby && timeTillFlyby_s < timeTillGunshotHeard_s;
			
			if (!ignoreGunshotHeard)
			{
				if (timeTillGunshotHeard_s < 0)
					OnGunshotHeard(utility, distance, dangerEventCount, shotPos);
				else
				{
					utility.GetCallqueue().CallLater(OnGunshotHeard, 1000*timeTillGunshotHeard_s, false,
						utility, distance, dangerEventCount, shotPos);
				}
			}
			
			if (isShotSuppressed && distance < 50)
			{
				auto investigaste = new SCR_AIMoveAndInvestigateBehavior(utility, null, shotPos,
				SCR_AIActionBase.PRIORITY_BEHAVIOR_MOVE_AND_INVESTIGATE, SCR_AIActionBase.PRIORITY_LEVEL_NORMAL, isDangerous: true, radius: 25, targetUnitType: EAIUnitType.UnitType_Infantry, duration: 150); 
				
				utility.AddAction(investigaste);
			}
		}
		
		if (isFlyby || isAudible)
		{
			// Notify our group, only if we are a leader
			
			
			AIGroup myGroup = utility.GetOwner().GetParentGroup();
			if (myGroup && myGroup.GetLeaderAgent() == agent)
			{
				float timeTillGroupNotified_s = Math.Min(timeTillFlyby_s, timeTillGunshotHeard_s);
				
				if (timeTillGroupNotified_s < 0)
					NotifyGroup(myGroup, shooter, instigatorEntity, instigatorFaction, shotPos, endangeringForGroup);
				else
				{
					utility.GetCallqueue().CallLater(NotifyGroup, 1000*timeTillGroupNotified_s, false,
						myGroup, shooter, instigatorEntity, instigatorFaction, shotPos, endangeringForGroup);
				}
			}
		}
		
		return true;
	}
	
	protected bool IsAudiable(float dist, bool isSuppressed)
	{
		float maxAudibleDistance;
		if (isSuppressed)
			maxAudibleDistance = AUDIBLE_DISTANCE_SUPPRESSED;
		else
			maxAudibleDistance = AUDIBLE_DISTANCE_NORMAL;
		
		if (isSuppressed && dist > 70)
			return Math.RandomFloat01() > 0.65;
		
		return dist < maxAudibleDistance;
	}
}